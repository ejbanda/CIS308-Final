#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "types.h"

char answers[1048][200];
char questions[275][500];

GameDB db;

//char p1Deck[5][200];
//char p2Deck[5][200];
void createAnswers(){
  //char answers[1048][200];

  //GameDB tcards; 
  FILE *file = fopen("answers.txt" ,"r");
  char buff[200];
  int i = 0;
  while(fgets(buff, 200, file) != NULL){
    strcpy(db.Answers[i].info, buff);
    i++;
  }
  fclose(file);
  
}

void createQuestions(){
  FILE *file = fopen("questions.txt" ,"r");
  char buff[500];
  int i = 0;
  while(fgets(buff, 500, file) != NULL){
    strcpy(db.Questions[i].info, buff);
    i++;
  }
  fclose(file);
  
}

void removeCard(int index){

      //for (int c = index - 1; c < n - 1; c++)
        // answers[c] = answers[c+1];
}

void printHand(player playerHand){
    for(int count = 1; count <=5; count++){
      printf("%d.  %s", count, playerHand.hand.cards[count-1].info);
    }
}

boolean questionDupeCheck(int number, GameDB db){
  for(int count = 0; count < db.round; count++){
    if(db.AnswersUsed[count] == number){
      return 0;
    }
  }
  return 1;
}

void threePlayer(char * first, char * second){

  GameDB data;
  data.round = 0;
  player playerOne, playerTwo;
  playerOne.score = 0;
  playerTwo.score = 0; 
  //playerOne.name = name1;
  strcpy(playerOne.name, first);
  strcpy(playerTwo.name, second);
	int duplicate =0;
  srand(time(NULL));
  for(int count = 0; count < 5; count++){
    int rand1 = rand() % 1048;
    int rand2 = rand() % 1048;
    data.AnswersUsed[count] = rand1;
    data.AnswersUsed[count + 1] = rand2;
	duplicate++;
    strcpy(playerOne.hand.cards[count].info, db.Answers[rand1].info);
    strcpy(playerTwo.hand.cards[count].info, db.Answers[rand2].info);
  }
  system("clear");

  while(playerOne.score < 5 && playerTwo.score < 5){
      data.round++;
      int randomQuestion = rand() % 275;
      int player1Choice, player2Choice, judgeChoice;


      printf("\n%s pick your card\n", first);
      printf("%s", db.Questions[randomQuestion].info);
      printHand(playerOne);
      scanf("%d", &player1Choice);
      system("clear");

      printf("\n%s pick your card\n", second);
      printf("%s", db.Questions[randomQuestion].info);
      printHand(playerTwo);
      scanf("%d", &player2Choice);
     system("clear");


      printf("\n%s", db.Questions[randomQuestion].info);
      printf("1. %s", playerOne.hand.cards[player1Choice - 1].info);
      printf("2. %s", playerTwo.hand.cards[player2Choice - 1].info);

      scanf("%d", &judgeChoice);

      if(judgeChoice == 1)
        playerOne.score += 1;
      else if(judgeChoice == 2)
        playerTwo.score += 1;

      boolean again;
      int new1, new2;

        do{
        new1 = rand() % 1048;
        new2 = rand() % 1048;
        again = False;

        if(questionDupeCheck(new1, data) == 0){
          new1 = rand() % 1048;
          again = True;
        }
        else if(questionDupeCheck(new2, data) == 0){
            new2 = rand() % 1048;
            again = True;
        }

      }while(again == True);
	data.AnswersUsed[duplicate + 1] = new1;
	duplicate++;
	data.AnswersUsed[duplicate + 1] = new2;
      	duplicate++;
      strcpy(playerOne.hand.cards[player1Choice - 1].info, db.Answers[new1].info);
      strcpy(playerTwo.hand.cards[player2Choice - 1].info, db.Answers[new2].info);

      system("clear");
  
}

if(playerOne.score == 5)
  printf("Player 1 won the game.\n");
else
  printf("Player 2 won the game.\n");

printf("Player one score:  %d\n", playerOne.score);
printf("Player two score:  %d\n", playerTwo.score);






}
int main(){
    createQuestions();
    createAnswers();

    char name1[10];
    char name2[10];

    //GameData cards = createAnswers();
    //strcpy(cards.Answers, createAnswers());
    

	system("clear");
    printf("Player 1 enter your name:  ");
    //scanf("%s", &name);  - deprecated
    scanf("%s", name1);
    printf("Player 2 enter your name:  ");
    scanf("%s", name2);

    threePlayer(name1, name2);
    
	return 0;
}
