#ifndef Player_h
#define Player_h
typedef struct player{
	int score;
	char name[10];
}player;

#endif